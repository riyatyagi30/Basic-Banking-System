# Projects
Intern at Sparks Foundation batch May 2021.
Task 1:
This is a Basic Banking System.
The project is done using HTML, CSS and a little JS.
A sample database is created with 10 customers.
The home page has the options to transfer moeny and to show transaction history and to create users.
The transaction history shows the details of the transaction made by a customer.
